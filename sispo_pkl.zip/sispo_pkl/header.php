<header>
    <h1>Sistem Informasi PKL SMK N 9 Medan</h1>
    <p>Siswa - Halaman untuk Isi Jurnal dan Absen Serta Konsultasi dengan Pembimbing</p> 
</header>