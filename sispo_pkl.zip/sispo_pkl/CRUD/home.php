 <!DOCTYPE html> 
 <html lang="en"> 
 <head> 
     <meta charset="UTF-8"> 
     <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
     <title>Halaman Konsultasi</title> 
     <link rel="stylesheet" href="style.css"> 
      
 </head> 
 <body> 
     <div class="chat-container"> 
         <h2>Selamat Datang di Sistem Informasi PKL SMKN 9 Medan </h2> 
         <p>Sistem informasi PKL ini digunakan sebagai media konsultasi 
            atau pembimbingan bagi siswa kepada guru pembimbing disekolah. 
            Silahkan ananda berkonsultasi jika ada kendala/masalah yang dihadapi di tempat kerja. 
         </p> 
          <p>Kami memahami bahwa kegiatan PKL bisa saja menghadirkan tantangan.
            Oleh karena itu, sistem ini menyediakan fitur konsultasi yang dapat
             Ananda gunakan untuk berdiskusi dan meminta bimbingan langsung dari
              guru pembimbing.</p>
     </div> 
  
      
 </body>
 </html>